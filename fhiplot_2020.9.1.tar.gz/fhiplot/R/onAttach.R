.onAttach <- function(libname, pkgname) {
  packageStartupMessage("PACKAGE: fhiplot")
  packageStartupMessage("Version 2020.09.01 at 04:50")
  packageStartupMessage("Developed by Richard White, Norwegian Institute of Public Health")
}
